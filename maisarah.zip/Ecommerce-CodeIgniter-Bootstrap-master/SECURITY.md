# Security Policy

## Reporting a Vulnerability

Please, contact me on email - kirilkirkov91@gmail.com
