<?php 
$lang['first'] = ' πρώτος';
$lang['last'] = 'τελευταίος';
$lang['next'] = 'επόμενος';
$lang['previous'] = 'προηγούμενος';
